import "dotenv/config";
import express from "express";
import cors from "cors";
import multer from "multer";
import fs from "fs";
import fsp from "fs/promises";
import path from "path";
import crypto from "crypto";
import { fileURLToPath } from "url";
import ffmpegPath from "ffmpeg-static";
import { spawn } from "child_process";
import OpenAI from "openai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const MAX_UPLOAD_BYTES = Number(process.env.MAX_UPLOAD_BYTES || 2147483648);
const STORAGE = path.join(__dirname, "storage");
const UPLOADS = path.join(STORAGE, "uploads");
const JOBS = path.join(STORAGE, "jobs");
const OUTPUTS = path.join(STORAGE, "outputs");

for (const dir of [UPLOADS, JOBS, OUTPUTS]) await fsp.mkdir(dir, { recursive: true });

const app = express();
app.use(cors());
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const jobs = new Map();

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS),
  filename: (_req, file, cb) => {
    const safe = path.basename(file.originalname).replace(/[^a-zA-Z0-9._-]/g, "_");
    cb(null, `${crypto.randomUUID()}-${safe}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: MAX_UPLOAD_BYTES },
  fileFilter: (_req, file, cb) => {
    const ok = /^(video|audio)\//.test(file.mimetype);
    cb(ok ? null : new Error("Only video and audio files are supported."), ok);
  }
});

function jsonError(res, status, message) {
  return res.status(status).json({ error: message });
}

async function saveJob(job) {
  jobs.set(job.id, job);
  await fsp.writeFile(path.join(JOBS, `${job.id}.json`), JSON.stringify(job, null, 2));
}

async function updateJob(id, patch) {
  const old = jobs.get(id) || {};
  const next = { ...old, ...patch, updatedAt: new Date().toISOString() };
  jobs.set(id, next);
  await fsp.writeFile(path.join(JOBS, `${id}.json`), JSON.stringify(next, null, 2));
  return next;
}

function runFFmpeg(args) {
  return new Promise((resolve, reject) => {
    const child = spawn(ffmpegPath, ["-y", ...args], { stdio: ["ignore", "pipe", "pipe"] });
    let stderr = "";
    child.stderr.on("data", d => { stderr += d.toString(); });
    child.on("error", reject);
    child.on("close", code => {
      if (code === 0) resolve();
      else reject(new Error(`FFmpeg failed (${code}): ${stderr.slice(-3000)}`));
    });
  });
}

function extFromMime(mime) {
  const map = {
    "video/mp4": ".mp4", "video/webm": ".webm", "video/quicktime": ".mov",
    "audio/mpeg": ".mp3", "audio/wav": ".wav", "audio/x-wav": ".wav",
    "audio/mp4": ".m4a", "audio/webm": ".webm", "audio/ogg": ".ogg"
  };
  return map[mime] || "";
}

async function transcribe(audioPath, filename) {
  const result = await openai.audio.transcriptions.create({
    file: fs.createReadStream(audioPath),
    model: process.env.TRANSCRIBE_MODEL || "gpt-4o-transcribe",
    response_format: "json"
  });
  return result.text || "";
}

async function translate(text, targetLanguage) {
  const response = await openai.responses.create({
    model: process.env.TEXT_MODEL || "gpt-5.6-luna",
    input: [
      {
        role: "system",
        content: "You are a professional audiovisual dubbing translator. Preserve meaning, names, tone, intent and conversational naturalness. Return only the translated dialogue, with no notes, headings or explanation."
      },
      {
        role: "user",
        content: `Translate the following dialogue into ${targetLanguage}. Keep it natural for spoken dubbing and avoid adding information.\n\n${text}`
      }
    ]
  });
  return response.output_text?.trim() || "";
}

async function makeTTS(text, targetLanguage, outputPath) {
  const speech = await openai.audio.speech.create({
    model: process.env.TTS_MODEL || "gpt-4o-mini-tts",
    voice: process.env.TTS_VOICE || "coral",
    input: text,
    instructions: `Speak naturally for professional video dubbing in ${targetLanguage}. Clear pronunciation, expressive but controlled delivery, consistent pacing.`
  });
  const buffer = Buffer.from(await speech.arrayBuffer());
  await fsp.writeFile(outputPath, buffer);
}

async function processJob(job) {
  try {
    if (!process.env.OPENAI_API_KEY) throw new Error("OPENAI_API_KEY is not configured on the server.");

    await updateJob(job.id, { status: "processing", progress: 10, stage: "Preparing media" });

    const source = job.sourcePath;
    const workDir = path.join(JOBS, job.id);
    await fsp.mkdir(workDir, { recursive: true });

    const extractedAudio = path.join(workDir, "source.wav");
    await updateJob(job.id, { progress: 18, stage: "Extracting original speech" });

    await runFFmpeg([
      "-i", source,
      "-vn", "-ac", "1", "-ar", "16000",
      "-c:a", "pcm_s16le",
      extractedAudio
    ]);

    await updateJob(job.id, { progress: 35, stage: "Transcribing speech with AI" });
    const transcript = await transcribe(extractedAudio, path.basename(source));
    if (!transcript.trim()) throw new Error("No speech was detected in the uploaded media.");

    await fsp.writeFile(path.join(workDir, "transcript.txt"), transcript);

    await updateJob(job.id, { progress: 52, stage: `Translating into ${job.targetLanguage}` });
    const translated = await translate(transcript, job.targetLanguage);
    if (!translated.trim()) throw new Error("Translation returned no text.");

    await fsp.writeFile(path.join(workDir, "translated.txt"), translated);

    const voicePath = path.join(OUTPUTS, `${job.id}-voiceover.wav`);
    await updateJob(job.id, { progress: 70, stage: "Generating ultra-realistic voiceover" });
    await makeTTS(translated, job.targetLanguage, voicePath);

    let videoUrl = null;
    if (job.isVideo) {
      const videoPath = path.join(OUTPUTS, `${job.id}-dubbed.mp4`);
      await updateJob(job.id, { progress: 84, stage: "Rendering dubbed MP4" });

      // Replace the original audio with the generated voice track.
      // The video stream is copied to preserve quality and avoid unnecessary re-encoding.
      await runFFmpeg([
        "-i", source,
        "-i", voicePath,
        "-map", "0:v:0",
        "-map", "1:a:0",
        "-c:v", "copy",
        "-c:a", "aac",
        "-b:a", "192k",
        "-shortest",
        "-movflags", "+faststart",
        videoPath
      ]);
      videoUrl = `/api/jobs/${job.id}/download/video`;
    }

    await updateJob(job.id, {
      status: "completed",
      progress: 100,
      stage: "Completed",
      transcript,
      translated,
      voiceUrl: `/api/jobs/${job.id}/download/voice`,
      videoUrl
    });
  } catch (err) {
    console.error(err);
    await updateJob(job.id, {
      status: "failed",
      progress: 100,
      stage: "Failed",
      error: err?.message || "Dubbing failed."
    });
  }
}

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    service: "AnimeToon AI Dubbing Studio",
    configured: Boolean(process.env.OPENAI_API_KEY)
  });
});

app.post("/api/jobs", upload.single("media"), async (req, res) => {
  try {
    if (!req.file) return jsonError(res, 400, "Please upload a video or audio file.");
    const targetLanguage = String(req.body.targetLanguage || "").trim();
    if (!targetLanguage) {
      await fsp.unlink(req.file.path).catch(() => {});
      return jsonError(res, 400, "Choose a target language.");
    }

    const job = {
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status: "queued",
      progress: 0,
      stage: "Queued",
      targetLanguage,
      sourceName: req.file.originalname,
      sourcePath: req.file.path,
      isVideo: req.file.mimetype.startsWith("video/"),
      options: {
        lipSyncTiming: req.body.lipSyncTiming === "true",
        preserveSfx: req.body.preserveSfx === "true",
        smartVoiceDetection: req.body.smartVoiceDetection === "true"
      }
    };

    await saveJob(job);
    processJob(job).catch(console.error);

    res.status(202).json({
      jobId: job.id,
      status: job.status,
      message: "Job accepted."
    });
  } catch (err) {
    console.error(err);
    jsonError(res, 500, err.message || "Upload failed.");
  }
});

app.get("/api/jobs/:id", async (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) {
    const file = path.join(JOBS, `${req.params.id}.json`);
    try {
      const loaded = JSON.parse(await fsp.readFile(file, "utf8"));
      jobs.set(loaded.id, loaded);
      return res.json(publicJob(loaded));
    } catch {
      return jsonError(res, 404, "Job not found.");
    }
  }
  res.json(publicJob(job));
});

function publicJob(job) {
  const { sourcePath, ...safe } = job;
  return safe;
}

async function sendOutput(res, jobId, kind) {
  const suffix = kind === "video" ? "-dubbed.mp4" : "-voiceover.wav";
  const file = path.join(OUTPUTS, `${jobId}${suffix}`);
  try {
    await fsp.access(file);
  } catch {
    return jsonError(res, 404, "The requested output is not available.");
  }
  res.download(file, kind === "video"
    ? "AnimeToon-AI-Dubbed-Video.mp4"
    : "AnimeToon-AI-Voiceover.wav");
}

app.get("/api/jobs/:id/download/video", async (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job || job.status !== "completed" || !job.videoUrl) return jsonError(res, 409, "Video is not ready.");
  await sendOutput(res, req.params.id, "video");
});

app.get("/api/jobs/:id/download/voice", async (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job || job.status !== "completed") return jsonError(res, 409, "Voiceover is not ready.");
  await sendOutput(res, req.params.id, "voice");
});

app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError) {
    if (err.code === "LIMIT_FILE_SIZE") return jsonError(res, 413, "The file is larger than the 2 GB upload limit.");
    return jsonError(res, 400, err.message);
  }
  console.error(err);
  jsonError(res, 500, err.message || "Server error.");
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`AnimeToon AI Dubbing Studio running on http://localhost:${PORT}`);
});
