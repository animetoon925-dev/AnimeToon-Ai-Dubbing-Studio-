# AnimeToon AI Dubbing Studio

This is a real backend-connected dubbing application, not a fake browser download demo.

## What it does

1. Accepts video/audio uploads up to 2 GB.
2. Saves the original media on the server.
3. Extracts audio with FFmpeg.
4. Transcribes speech with OpenAI.
5. Translates the transcript into the selected target language.
6. Generates a real target-language voice track with OpenAI TTS.
7. Creates a real WAV voiceover file.
8. Creates a real MP4 with the generated voice track.
9. Serves the completed files through actual download URLs.
10. Keeps job status so the browser can poll processing progress.

## Important accuracy note

No AI dubbing system can honestly guarantee 100% accuracy for every accent, speaker, noise condition, language, joke, name, or lip movement. This project is designed for professional-quality automated dubbing, with a human-review step recommended for important releases.

## Requirements

- Node.js 20+
- An OpenAI API key with access to the configured transcription, text, and TTS models.
- Internet access from the server for OpenAI API calls.

## Run

```bash
npm install
cp .env.example .env
# edit .env and add OPENAI_API_KEY
npm start
```

Open:

http://localhost:3000

## Production deployment

Put the app behind HTTPS and a reverse proxy. For 2 GB uploads, make sure the proxy accepts at least 2 GB request bodies and has a long request timeout. Use persistent object storage (S3/R2/GCS) instead of local disk for multi-server deployments.

The included local disk storage is intentionally simple so the project runs immediately on one server.

## Download behavior

The Download buttons do not generate placeholder text. They point to the actual server-side MP4/WAV outputs created by FFmpeg and OpenAI. If processing fails, the UI shows the server error and no fake download is offered.

## Lip-sync

Voice timing and video audio replacement are implemented. True phoneme-level visual lip synchronization is a separate video-generation pipeline and should not be falsely represented as complete by a normal HTML/FFmpeg audio replacement. A dedicated lip-sync model/service can be added as a post-processing worker without changing the download architecture.


## Landing page

The homepage is now a complete modern SaaS marketing site with:
- sticky responsive navigation
- animated product/dashboard preview
- hero CTA and product positioning
- bento feature section
- four-step workflow
- voice assignment/export showcase
- pricing cards
- testimonials
- FAQ accordion
- final conversion CTA
- responsive mobile layout
- sign-in modal placeholder ready for real authentication
